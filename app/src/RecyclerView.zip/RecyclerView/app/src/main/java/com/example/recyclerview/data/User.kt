package com.example.recyclerview.data

data class User (val nombre: String) {
}